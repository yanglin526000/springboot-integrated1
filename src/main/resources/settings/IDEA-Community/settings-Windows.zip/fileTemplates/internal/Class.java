/**
* ClassName: ${NAME} <br/>
* Description: <br/>
* date: ${DATE} ${TIME}<br/>
* @author ${USER}<br/>
*/
public class ${NAME} {
}
